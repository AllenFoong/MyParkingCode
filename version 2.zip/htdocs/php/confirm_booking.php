<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    die("Unauthorized access.");
}

$user_id = $_SESSION['user_id'];
$slot_id = $_POST['slot_id'];
$res_date = $_POST['reservation_date'];
$res_time = $_POST['reservation_time'];
$book_time = date('Y-m-d H:i:s');

// Check if already booked at that date/time
$check = mysqli_query($conn, "SELECT * FROM bookings 
    WHERE slot_id = $slot_id 
    AND reservation_date = '$res_date'
    AND reservation_time = '$res_time'");

if (mysqli_num_rows($check) > 0) {
    echo "Slot already booked at that time. <a href='../dashboard.html'>Back</a>";
    exit;
}

// Insert booking
mysqli_query($conn, "INSERT INTO bookings (user_id, slot_id, booking_time, reservation_date, reservation_time)
VALUES ($user_id, $slot_id, '$book_time', '$res_date', '$res_time')");

echo "Booking confirmed for $res_date at $res_time. <a href='../dashboard.html'>Back to Dashboard</a>";
?>
