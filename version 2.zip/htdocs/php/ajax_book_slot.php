<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo "Login required.";
    exit;
}

$user_id = $_SESSION['user_id'];
$slot_id = $_POST['slot_id'];
$res_date = $_POST['reservation_date'];
$res_time = $_POST['reservation_time'];
$book_time = date('Y-m-d H:i:s');

$exists = mysqli_query($conn, "SELECT * FROM bookings 
    WHERE slot_id = $slot_id 
    AND reservation_date = '$res_date' 
    AND reservation_time = '$res_time'");

if (mysqli_num_rows($exists) > 0) {
    echo "This slot is already booked at that date/time.";
    exit;
}

mysqli_query($conn, "INSERT INTO bookings (user_id, slot_id, booking_time, reservation_date, reservation_time)
    VALUES ($user_id, $slot_id, '$book_time', '$res_date', '$res_time')");

echo "Booking confirmed for $res_date at $res_time!";
?>
