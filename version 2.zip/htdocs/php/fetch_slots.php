<?php
include 'db.php';

$result = mysqli_query($conn, "SELECT * FROM slots");
$today = date('Y-m-d'); // You can later change this to a selected date

echo "<div class='slots-container'>";

while ($row = mysqli_fetch_assoc($result)) {
    $slot_id = $row['id'];
    $slot_number = $row['slot_number'];

    // Check if this slot is booked for today
    $booking_check = mysqli_query($conn, 
        "SELECT reservation_time FROM bookings 
         WHERE slot_id = $slot_id 
         AND reservation_date = '$today' 
         LIMIT 1");

    echo "<div class='slot-card' id='slot-$slot_id'>";

    // Picture section
    //$imagePath = "images/" . strtolower($slot['slot_number']) . ".jpg";
    //echo "<div class='slot-image'>
        //     <img src='$imagePath' alt='Slot Image' />
        // </div>";

    $slotName = strtolower($row['slot_number']); // e.g. a1, b1
    $imagePath = "images/{$slotName}.jpg"; // or change to .png if your files are .png

    echo "<div class='slot-image'>
            <img src='$imagePath' alt='Slot $slotName Image' />
        </div>";



    // Info & booking section
    echo "<div class='slot-info'>";
    echo "<div class='slot-title'>Slot: " . htmlspecialchars($slot_number) . "</div>";

    // Time selection buttons
    $times = ['09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00'];
    echo "<div class='time-buttons'>";
    foreach ($times as $t) {
        $display = date("g:i A", strtotime($t));
        echo "<button class='time-btn' onclick=\"selectTime($slot_id, '$t')\">$display</button>";
    }
    echo "</div>";

    // Date picker + Book
    echo "<div class='booking-controls'>";
    echo "<input type='date' id='date-$slot_id' onchange=\"validateForm($slot_id)\">";
    echo "<button id='book-$slot_id' class='book-btn' disabled onclick=\"submitBooking($slot_id, $slot_id)\">Book</button>";
    echo "</div>";

    echo "</div>"; // end slot-info
    echo "</div>"; // end slot-card


}

echo "</div>"; // end slots-container
?>
