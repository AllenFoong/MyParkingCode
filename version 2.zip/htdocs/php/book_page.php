<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    die("Please <a href='../login.html'>login</a> to book.");
}
$slot_id = $_POST['slot_id'];
?>

<!DOCTYPE html>
<html>
<head><title>Select Date & Time</title></head>
<body>
<h2>Select Reservation Date & Time</h2>
<form action="confirm_booking.php" method="POST">
  <input type="hidden" name="slot_id" value="<?= $slot_id ?>">
  <label>Date:</label>
  <input type="date" name="reservation_date" required><br><br>
  <label>Time:</label>
  <input type="time" name="reservation_time" required><br><br>
  <button type="submit">Confirm Booking</button>
</form>
</body>
</html>
